<?php
    $con=mysqli_connect('localhost','root','','blog_app') or die(mysqli_connect_error());
?>