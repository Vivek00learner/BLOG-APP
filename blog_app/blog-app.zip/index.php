<!Doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Blog App</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
  <?php require('inc/header.php');?>
  <div class="container">
    <div class="row">
      <div class="col-12 text-center my-3">
        <h3 class="h3">Latest News</h3>
      </div>
    </div>
    <div class="row">
      <div class="col-3 my-2">
        <div class="card" >
          <img src="https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Card title</h5>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's
              content. <br><a href="">Read More...</a></p>
          </div>
          <ul class="list-group list-group-flush">
            <li class="list-group-item"><b>Author : </b>News24</li>
            <li class="list-group-item"><B>Date :</b> 12 Dec 2022</li>
          </ul>
        </div>
      </div> 
    </div>
  </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</html>