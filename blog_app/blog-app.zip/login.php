<!Doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>User Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
  <?php require('inc/header.php');?>
  <div class="container">
    <div class="row">
      <div class="col-md-6 offset-md-3 my-5">
        <?php
            if(isset($_REQUEST['submit']))
            {
                echo $_SERVER['REQUEST_METHOD'];
                echo "<br>";
                echo $_REQUEST['email'];
                echo "<br>";
                echo $_REQUEST['password'];
            }
        ?>
        <div class="card">
            <div class="card-header">
                <h6>Registed User Login</h6>
            </div>
            <div class="card-body">
                <form method="post" autocomplete="off">
                    <div class="form-group my-1">
                        <label>Enter Email</label>
                        <input type="email" class="form-control" name="email"/>
                    </div>
                    <div class="form-group my-1">
                        <label>Enter Password</label>
                        <input type="password" class="form-control" name="password"/>
                    </div>
                    <div class="form-group my-2">
                        <input type="submit" class="btn btn-success w-100" name="submit" value="LOGIN"/>
                    </div>
                </form>
            </div>
        </div>
      </div>
    </div>
  </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</html>